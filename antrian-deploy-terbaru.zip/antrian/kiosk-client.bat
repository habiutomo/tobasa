@echo off
title Antrian Tobasa - Ambil Antrian
rem ============================================
rem   BUKA APLIKASI ANTRIAN + AUTO CETAK STRUK
rem   - Membuka /kiosk di jendela browser normal
rem   - Otomatis konfirmasi preview struk (halaman 1)
rem   - Stop: tutup jendela "Auto Cetak Struk"
rem ============================================
setlocal
set "URL=http://tobasa.elnusaintegrated.cloud/kiosk"

echo ========================================
echo   BUKA ANTRIAN + AUTO CETAK - TOBASA
echo   Membuka: %URL%
echo ========================================
echo.

rem Coba Microsoft Edge
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
    start "" "%EDGE%" --start-maximized --no-first-run --no-default-browser-check "%URL%"
    goto autoprint
)

rem Coba Google Chrome
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
    start "" "%CHROME%" --start-maximized --no-first-run --no-default-browser-check "%URL%"
    goto autoprint
)

set "CHROME_X86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME_X86%" (
    start "" "%CHROME_X86%" --start-maximized --no-first-run --no-default-browser-check "%URL%"
    goto autoprint
)

rem Fallback: browser default
start "" "%URL%"

:autoprint
set "B64=QQBkAGQALQBUAHkAcABlACAALQBBAHMAcwBlAG0AYgBsAHkATgBhAG0AZQAgAFMAeQBzAHQAZQBtAC4AVwBpAG4AZABvAHcAcwAuAEYAbwByAG0AcwAKAEEAZABkAC0AVAB5AHAAZQAgAC0ATQBlAG0AYgBlAHIARABlAGYAaQBuAGkAdABpAG8AbgAgACcACgBbAEQAbABsAEkAbQBwAG8AcgB0ACgAIgB1AHMAZQByADMAMgAuAGQAbABsACIAKQBdACAAcAB1AGIAbABpAGMAIABzAHQAYQB0AGkAYwAgAGUAeAB0AGUAcgBuACAASQBuAHQAUAB0AHIAIABHAGUAdABGAG8AcgBlAGcAcgBvAHUAbgBkAFcAaQBuAGQAbwB3ACgAKQA7AAoAWwBEAGwAbABJAG0AcABvAHIAdAAoACIAdQBzAGUAcgAzADIALgBkAGwAbAAiACwAIABDAGgAYQByAFMAZQB0AD0AQwBoAGEAcgBTAGUAdAAuAFUAbgBpAGMAbwBkAGUAKQBdACAAcAB1AGIAbABpAGMAIABzAHQAYQB0AGkAYwAgAGUAeAB0AGUAcgBuACAAaQBuAHQAIABHAGUAdABXAGkAbgBkAG8AdwBUAGUAeAB0ACgASQBuAHQAUAB0AHIAIABoAFcAbgBkACwAIABTAHkAcwB0AGUAbQAuAFQAZQB4AHQALgBTAHQAcgBpAG4AZwBCAHUAaQBsAGQAZQByACAAbABwAFMAdAByAGkAbgBnACwAIABpAG4AdAAgAG4ATQBhAHgAQwBvAHUAbgB0ACkAOwAKACcAIAAtAE4AYQBtAGUAIABXAGkAbgBBAHAAaQAgAC0ATgBhAG0AZQBzAHAAYQBjAGUAIABLAGkAbwBzAGsACgB3AGgAaQBsAGUAIAAoACQAdAByAHUAZQApACAAewAKACAAIAAgACAAUwB0AGEAcgB0AC0AUwBsAGUAZQBwACAALQBNAGkAbABsAGkAcwBlAGMAbwBuAGQAcwAgADQAMAAwAAoAIAAgACAAIAAkAHMAYgAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4AUwB0AHIAaQBuAGcAQgB1AGkAbABkAGUAcgAgADIANQA2AAoAIAAgACAAIABbAHYAbwBpAGQAXQBbAEsAaQBvAHMAawAuAFcAaQBuAEEAcABpAF0AOgA6AEcAZQB0AFcAaQBuAGQAbwB3AFQAZQB4AHQAKABbAEsAaQBvAHMAawAuAFcAaQBuAEEAcABpAF0AOgA6AEcAZQB0AEYAbwByAGUAZwByAG8AdQBuAGQAVwBpAG4AZABvAHcAKAApACwAIAAkAHMAYgAsACAAMgA1ADYAKQAKACAAIAAgACAAJAB0AGkAdABsAGUAIAA9ACAAJABzAGIALgBUAG8AUwB0AHIAaQBuAGcAKAApAAoAIAAgACAAIABpAGYAIAAoACQAdABpAHQAbABlACAALQBtAGEAdABjAGgAIAAnAHAAcgBpAG4AdAAnACAALQBvAHIAIAAkAHQAaQB0AGwAZQAgAC0AbQBhAHQAYwBoACAAJwBjAGUAdABhAGsAJwAgAC0AbwByACAAJAB0AGkAdABsAGUAIAAtAG0AYQB0AGMAaAAgACcAcAByAGUAdgBpAGUAdwAnACkAIAB7AAoAIAAgACAAIAAgACAAIAAgAFMAdABhAHIAdAAtAFMAbABlAGUAcAAgAC0ATQBpAGwAbABpAHMAZQBjAG8AbgBkAHMAIAAzADAAMAAKACAAIAAgACAAIAAgACAAIABbAFMAeQBzAHQAZQBtAC4AVwBpAG4AZABvAHcAcwAuAEYAbwByAG0AcwAuAFMAZQBuAGQASwBlAHkAcwBdADoAOgBTAGUAbgBkAFcAYQBpAHQAKAAnAHsARQBOAFQARQBSAH0AJwApAAoAIAAgACAAIAAgACAAIAAgAFMAdABhAHIAdAAtAFMAbABlAGUAcAAgAC0AUwBlAGMAbwBuAGQAcwAgADMACgAgACAAIAAgAH0ACgB9AA=="
start "Auto Cetak Struk" /min powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand "%B64%"
echo.
echo   Pemantau auto-cetak berjalan di jendela mini.
echo   Saat preview struk muncul, otomatis ditekan tombol Cetak (halaman 1).
echo   Tutup jendela "Auto Cetak Struk" untuk berhenti.
echo.
pause

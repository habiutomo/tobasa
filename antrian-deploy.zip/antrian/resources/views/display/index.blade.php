<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layar Antrian - {{ $namaPuskesmas }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body {
            height: 100%;
            overflow: hidden;
            background: #0f2a5a;
            font-family: "Segoe UI", system-ui, sans-serif;
        }
        .header {
            background: linear-gradient(90deg, #0d6efd, #0a4fb0);
            color: #fff;
            padding: 18px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 4px solid #ffc107;
        }
        .header .title { font-size: 2rem; font-weight: 800; letter-spacing: 1px; }
        .header .clock { text-align: right; }
        .header .clock .waktu { font-size: 2.4rem; font-weight: 800; font-variant-numeric: tabular-nums; }
        .header .clock .tanggal { font-size: 1rem; opacity: .9; }

        .loket-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 18px;
            padding: 22px 28px;
            flex: 1;
        }
        .loket-card {
            background: #fff;
            border-radius: 18px;
            padding: 18px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            box-shadow: 0 8px 18px rgba(0,0,0,.25);
            border-left: 8px solid #6c757d;
        }
        .loket-card .name { font-size: 1.1rem; font-weight: 700; color: #333; }
        .loket-card .poli-label { font-size: .95rem; color: #6c757d; }
        .loket-card .angka {
            font-size: 6.5rem;
            font-weight: 900;
            line-height: 1;
            color: #343a40;
            font-variant-numeric: tabular-nums;
        }
        .loket-card.empty .angka { color: #ced4da; font-size: 4.5rem; }
        .loket-card.calling { border-left-color: #0d6efd; background: #eef4ff; }
        .loket-card.calling .angka { color: #0d6efd; animation: blink 1s step-start infinite; }
        @keyframes blink { 50% { opacity: .25; } }

        .section-right {
            width: 360px;
            background: rgba(255,255,255,.06);
            padding: 20px 24px;
            color: #fff;
            overflow-y: auto;
        }
        .section-right h4 {
            font-size: 1.1rem;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 16px;
            text-transform: uppercase;
            color: #ffc107;
        }
        .section-right .served-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 12px;
            margin-bottom: 8px;
            background: rgba(255,255,255,.08);
            border-radius: 10px;
            font-weight: 700;
            font-size: 1.05rem;
        }
        .served-item .no { font-size: 1.25rem; }
        .badge-status { font-size: .72rem; font-weight: 700; padding: 3px 10px; border-radius: 20px; }

        .marquee-wrap {
            background: #ffc107;
            color: #000;
            padding: 10px 0;
            white-space: nowrap;
            overflow: hidden;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
        }
        .marquee-wrap span {
            display: inline-block;
            padding-left: 100%;
            animation: marquee 25s linear infinite;
            font-weight: 700;
            font-size: 1.05rem;
        }
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-100%); } }

        .main-row {
            display: flex;
            height: calc(100vh - 110px - 46px);
        }
        .loket-area { flex: 1; display: flex; flex-direction: column; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title"><i class="bi bi-hospital"></i> {{ $namaPuskesmas }}</div>
        <div class="clock">
            <div class="tanggal" id="tanggal"></div>
            <div class="waktu" id="jam"></div>
        </div>
    </div>

    <div class="main-row">
        <div class="loket-area">
            <div class="loket-grid" id="loketGrid"></div>

            <div style="padding: 0 28px 18px; color:#fff;">
                <div class="d-flex justify-content-around align-items-center">
                    <div class="text-center"><div class="fs-6 opacity-75">Antrian Dipanggil</div><div class="fw-bold fs-4 text-warning" id="statCalling">0</div></div>
                    <div class="text-center"><div class="fs-6 opacity-75">Selesai</div><div class="fw-bold fs-4 text-success" id="statDone">0</div></div>
                    <div class="text-center"><div class="fs-6 opacity-75">Menunggu</div><div class="fw-bold fs-4 text-info" id="statWaiting">0</div></div>
                    <a href="{{ route('kiosk.index') }}" target="_blank" class="btn btn-outline-light btn-lg"><i class="bi bi-three-dots"></i> Ambil Antrian</a>
                </div>
            </div>
        </div>

        <div class="section-right">
            <h4>Nomor Terpanggil</h4>
            <div id="lastServed"></div>
        </div>
    </div>

    <div class="marquee-wrap">
        <span>{{ $marqueeText ?: 'Selamat datang di pelayanan kesehatan kami.' }}</span>
    </div>

    <script>
        const loketGrid = document.getElementById('loketGrid');
        const lastServed = document.getElementById('lastServed');
        let announced = {};

        function updateClock() {
            const now = new Date();
            const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            const tanggal = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
            document.getElementById('jam').textContent = jam;
            document.getElementById('tanggal').textContent = tanggal;
        }

        function speak(text) {
            if (!('speechSynthesis' in window)) return;
            window.speechSynthesis.cancel();
            const u = new SpeechSynthesisUtterance(text);
            u.lang = 'id-ID';
            u.rate = 0.95;
            window.speechSynthesis.speak(u);
        }

        function render(data) {
            let html = '';
            data.lokets.forEach(l => {
                const stateClass = l.is_calling ? 'calling' : 'empty';
                const angka = l.nomor_dipanggil ? l.nomor_dipanggil : '--';
                html += `
                    <div class="loket-card ${stateClass}">
                        <div class="name">${l.nama}</div>
                        <div class="poli-label">${l.poli ? l.poli : ''}</div>
                        <div class="angka">${angka}</div>
                        <div class="poli-label">${l.is_calling ? `<i class="bi bi-broadcast"></i> Sedang Dipanggil` : '&nbsp;'}</div>
                    </div>`;
                if (l.is_calling && l.nomor_dipanggil && announced[l.nomor_dipanggil] !== l.nama) {
                    announced[l.nomor_dipanggil] = l.nama;
                    speak(`Nomor ${l.nomor_dipanggil}, silakan menuju ${l.nama}.`);
                }
            });
            loketGrid.innerHTML = html;

            let served = '';
            data.last_served.forEach(s => {
                const badge = s.status === 'done'
                    ? '<span class="badge-status bg-success">Selesai</span>'
                    : s.status === 'skipped'
                        ? '<span class="badge-status bg-warning text-dark">Lewat</span>'
                        : '<span class="badge-status bg-info text-dark">Dipanggil</span>';
                served += `<div class="served-item"><span class="no">${s.no_antrian}</span><span class="text-muted small">${s.nama_poli}</span>${badge}</div>`;
            });
            lastServed.innerHTML = served || '<div class="text-muted">Belum ada antrian</div>';
        }

        async function load() {
            try {
                const res = await fetch('{{ route('display.data') }}');
                const data = await res.json();
                render(data);
            } catch (e) {
                console.error(e);
            }
        }

        updateClock();
        setInterval(updateClock, 1000);
        load();
        setInterval(load, 2000);
    </script>
</body>
</html>
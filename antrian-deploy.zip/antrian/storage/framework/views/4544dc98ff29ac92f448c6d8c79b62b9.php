<?php $__env->startSection('title', 'Kelola Loket'); ?>
<?php $__env->startSection('pageTitle', 'Kelola Loket'); ?>
<?php $__env->startSection('pageSubtitle', 'Konfigurasi loket pelayanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Tambah Loket</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.loket.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Nama Loket</label>
                        <input type="text" name="nama" class="form-control" placeholder="Loket 1 - Umum" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Poli</label>
                        <select name="poli_id" class="form-select" required>
                            <option value="">-- Pilih Poli --</option>
                            <?php $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($poli->id); ?>"><?php echo e($poli->nama); ?> (<?php echo e($poli->prefix); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-primary w-100">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Daftar Loket</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Loket</th>
                            <th>Poli</th>
                            <th>Status</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lokets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-bold"><?php echo e($loket->nama); ?></td>
                            <td><?php echo e($loket->poli?->nama ?? '-'); ?></td>
                            <td>
                                <?php if($loket->is_active): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Nonaktif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($loket->id); ?>">Edit</button>
                                <form action="<?php echo e(route('admin.loket.destroy', $loket)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Hapus loket ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>

                        <div class="modal fade" id="edit<?php echo e($loket->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('admin.loket.update', $loket)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit <?php echo e($loket->nama); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Nama Loket</label>
                                                <input type="text" name="nama" value="<?php echo e($loket->nama); ?>" class="form-control" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Poli</label>
                                                <select name="poli_id" class="form-select" required>
                                                    <?php $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($poli->id); ?>" <?php echo e($loket->poli_id == $poli->id ? 'selected' : ''); ?>>
                                                            <?php echo e($poli->nama); ?> (<?php echo e($poli->prefix); ?>)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-check form-switch">
                                                <input type="checkbox" name="is_active" value="1" class="form-check-input" id="aktif<?php echo e($loket->id); ?>" <?php echo e($loket->is_active ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="aktif<?php echo e($loket->id); ?>">Aktif</label>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/lokets.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Kelola Petugas'); ?>
<?php $__env->startSection('pageTitle', 'Kelola Petugas'); ?>
<?php $__env->startSection('pageSubtitle', 'Akun petugas loket dan administrator'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Tambah Petugas</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.user.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" minlength="6" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Peran</label>
                        <select name="role" class="form-select" onchange="document.getElementById('loketWrap').style.display = this.value === 'loket' ? 'block' : 'none';">
                            <option value="loket">Petugas Loket</option>
                            <option value="admin">Administrator</option>
                        </select>
                    </div>
                    <div class="mb-3" id="loketWrap">
                        <label class="form-label">Loket</label>
                        <select name="loket_id" class="form-select">
                            <option value="">-- Tanpa Loket --</option>
                            <?php $__currentLoopData = $lokets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($loket->id); ?>"><?php echo e($loket->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-primary w-100">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Daftar Petugas</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Peran</th>
                            <th>Loket</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-bold"><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->isAdmin()): ?>
                                    <span class="badge bg-primary">Admin</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Loket</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->loket?->nama ?? '-'); ?></td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($user->id); ?>">Edit</button>
                                <form action="<?php echo e(route('admin.user.destroy', $user)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Hapus petugas ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>

                        <div class="modal fade" id="edit<?php echo e($user->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('admin.user.update', $user)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit <?php echo e($user->name); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Nama</label>
                                                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Email</label>
                                                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Password (kosongkan jika tidak diganti)</label>
                                                <input type="password" name="password" class="form-control" minlength="6">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Peran</label>
                                                <select name="role" class="form-select">
                                                    <option value="loket" <?php echo e($user->role === 'loket' ? 'selected' : ''); ?>>Petugas Loket</option>
                                                    <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Administrator</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Loket</label>
                                                <select name="loket_id" class="form-select">
                                                    <option value="">-- Tanpa Loket --</option>
                                                    <?php $__currentLoopData = $lokets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($loket->id); ?>" <?php echo e($user->loket_id == $loket->id ? 'selected' : ''); ?>><?php echo e($loket->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/users.blade.php ENDPATH**/ ?>
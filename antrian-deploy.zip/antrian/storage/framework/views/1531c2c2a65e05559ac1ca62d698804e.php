<?php $__env->startSection('title', 'Laporan Antrian'); ?>
<?php $__env->startSection('pageTitle', 'Laporan Antrian'); ?>
<?php $__env->startSection('pageSubtitle', 'Rekap jumlah pasien per poli'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.laporan')); ?>" class="row g-3 align-items-end">
            <div class="col-auto">
                <label class="form-label small mb-1">Tanggal Awal</label>
                <input type="date" name="tanggal_awal" value="<?php echo e($tanggalAwal); ?>" class="form-control">
            </div>
            <div class="col-auto">
                <label class="form-label small mb-1">Tanggal Akhir</label>
                <input type="date" name="tanggal_akhir" value="<?php echo e($tanggalAkhir); ?>" class="form-control">
            </div>
            <div class="col-auto">
                <button class="btn btn-primary"><i class="bi bi-funnel"></i> Filter</button>
            </div>
            <div class="col-auto ms-auto d-flex gap-2">
                <button type="button" class="btn btn-outline-success" onclick="window.print()"><i class="bi bi-printer"></i> Cetak</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold"><?php echo e($total); ?></div>
            <div class="text-muted small">Total Antrian</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-success"><?php echo e($totalSelesai); ?></div>
            <div class="text-muted small">Selesai Dilayani</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-danger"><?php echo e($totalLewat); ?></div>
            <div class="text-muted small">Tidak Hadir / Lewat</div>
        </div>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white fw-bold">Rekap per Poli</div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Poli</th>
                    <th class="text-center">Total</th>
                    <th class="text-center">Menunggu</th>
                    <th class="text-center">Dipanggil</th>
                    <th class="text-center">Selesai</th>
                    <th class="text-center">Lewat</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $perPoli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="fw-bold"><?php echo e($p['poli']); ?></td>
                    <td class="text-center"><?php echo e($p['total']); ?></td>
                    <td class="text-center text-info"><?php echo e($p['waiting']); ?></td>
                    <td class="text-center text-warning"><?php echo e($p['dipanggil']); ?></td>
                    <td class="text-center text-success"><?php echo e($p['selesai']); ?></td>
                    <td class="text-center text-danger"><?php echo e($p['lewat']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white fw-bold">Detail Antrian</div>
    <div class="table-responsive" style="max-height:480px; overflow-y:auto;">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="table-light sticky-top">
                <tr>
                    <th>Tanggal</th>
                    <th>No. Antrian</th>
                    <th>Poli</th>
                    <th>Pasien</th>
                    <th>Loket</th>
                    <th>Status</th>
                    <th>Waktu</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $antrians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($a->tanggal->format('d M Y')); ?></td>
                    <td class="fw-bold"><?php echo e($a->no_antrian); ?></td>
                    <td><?php echo e($a->poli?->nama); ?></td>
                    <td><?php echo e($a->nama_pasien ?: '-'); ?></td>
                    <td><?php echo e($a->loket?->nama ?: '-'); ?></td>
                    <td>
                        <?php if($a->status === 'waiting'): ?>
                            <span class="badge bg-info">Menunggu</span>
                        <?php elseif($a->status === 'calling'): ?>
                            <span class="badge bg-warning text-dark">Dipanggil</span>
                        <?php elseif($a->status === 'done'): ?>
                            <span class="badge bg-success">Selesai</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Lewat</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($a->created_at->format('H:i')); ?> - <?php echo e(optional($a->finished_at)->format('H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Tidak ada data pada rentang tanggal tersebut</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Penyesuaian tampilan saat dicetak
    const style = document.createElement('style');
    style.textContent = '@media print { .sidebar, .d-flex.justify-content-between, form, .btn { display: none !important; } .col-lg-7, .col { padding: 0 !important; } }';
    document.head.appendChild(style);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/laporan.blade.php ENDPATH**/ ?>
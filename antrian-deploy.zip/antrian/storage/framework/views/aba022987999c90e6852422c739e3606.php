<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('pageTitle', 'Pengaturan'); ?>
<?php $__env->startSection('pageSubtitle', 'Konfigurasi umum sistem antrian'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold"><i class="bi bi-gear"></i> Pengaturan Umum</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.setting.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Nama Puskesmas</label>
                        <input type="text" name="nama_puskesmas" class="form-control" value="<?php echo e($namaPuskesmas); ?>" required>
                        <div class="form-text">Ditampilkan di layar antrian dan kiosk</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Teks Berjalan (Marquee)</label>
                        <input type="text" name="marquee_text" class="form-control" value="<?php echo e($marqueeText); ?>" maxlength="255">
                        <div class="form-text">Teks selamat datang di bawah layar antrian</div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Jam Buka</label>
                                <input type="time" name="jam_buka" class="form-control" value="<?php echo e($jamBuka); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="mb-3">
                                <label class="form-label">Jam Tutup</label>
                                <input type="time" name="jam_tutup" class="form-control" value="<?php echo e($jamTutup); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-check form-switch mb-4">
                        <input type="checkbox" name="kiosk_open" value="1" class="form-check-input" id="kioskOpen" <?php echo e($kioskOpen ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="kioskOpen">
                            <strong>Kiosk Pengambilan Antrian Aktif</strong>
                            <span class="d-block text-muted small">Jika nonaktif, pasien tidak dapat mengambil nomor antrian baru</span>
                        </label>
                    </div>
                    <button class="btn btn-primary w-100">Simpan Pengaturan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/settings.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<?php $__env->startSection('pageTitle', 'Dashboard'); ?>
<?php $__env->startSection('pageSubtitle', 'Ringkasan antrian hari ini'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3 mb-4">
    <div class="col-6 col-md-2">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-primary"><?php echo e($totalHariIni); ?></div>
            <div class="text-muted small">Total Antrian</div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-info"><?php echo e($menunggu); ?></div>
            <div class="text-muted small">Menunggu</div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-warning"><?php echo e($dipanggil); ?></div>
            <div class="text-muted small">Dipanggil</div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-success"><?php echo e($selesai); ?></div>
            <div class="text-muted small">Selesai</div>
        </div>
    </div>
    <div class="col-6 col-md-2">
        <div class="card text-center p-3 shadow-sm">
            <div class="fs-1 fw-bold text-danger"><?php echo e($lewat); ?></div>
            <div class="text-muted small">Lewat</div>
        </div>
    </div>
    <div class="col-6 col-md-2 d-grid">
        <a href="<?php echo e(route('display.index')); ?>" target="_blank" class="btn btn-outline-primary d-flex flex-column justify-content-center">
            <i class="bi bi-tv fs-4"></i> Layar Antrian
        </a>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span class="fw-bold">Antrian Hari Ini</span>
        <button class="btn btn-outline-danger btn-sm" onclick="if(confirm('Yakin reset semua antrian hari ini?')) document.getElementById('reset-form').submit();">
            <i class="bi bi-arrow-counterclockwise"></i> Reset Antrian
        </button>
        <form id="reset-form" action="<?php echo e(route('admin.reset-hari-ini')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>No. Antrian</th>
                    <th>Poli</th>
                    <th>Pasien</th>
                    <th>Loket</th>
                    <th>Status</th>
                    <th>Diambil</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $antrians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-bold"><?php echo e($a->no_antrian); ?></td>
                    <td><?php echo e($a->poli?->nama); ?></td>
                    <td><?php echo e($a->nama_pasien ?: '-'); ?></td>
                    <td><?php echo e($a->loket?->nama ?: '-'); ?></td>
                    <td>
                        <?php if($a->status === 'waiting'): ?>
                            <span class="badge bg-info">Menunggu</span>
                        <?php elseif($a->status === 'calling'): ?>
                            <span class="badge bg-warning text-dark">Dipanggil</span>
                        <?php elseif($a->status === 'done'): ?>
                            <span class="badge bg-success">Selesai</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Lewat</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($a->created_at->format('H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Belum ada antrian hari ini</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
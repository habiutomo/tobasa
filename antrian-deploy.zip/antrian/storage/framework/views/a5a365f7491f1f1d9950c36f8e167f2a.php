<?php $__env->startSection('title', 'Kelola Layanan'); ?>
<?php $__env->startSection('pageTitle', 'Kelola Layanan'); ?>
<?php $__env->startSection('pageSubtitle', 'Layanan per klaster untuk pengambilan antrian'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Tambah Layanan</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.polis.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Klaster</label>
                        <select name="klaster_id" class="form-select" required>
                            <option value="">-- Pilih Klaster --</option>
                            <?php $__currentLoopData = $klasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($klaster->id); ?>"><?php echo e($klaster->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Layanan</label>
                        <input type="text" name="nama" class="form-control" placeholder="KIA" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kode Huruf</label>
                        <input type="text" name="prefix" class="form-control" maxlength="4" placeholder="A" required>
                        <div class="form-text">Format nomor antrian, misal: A (A001)</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Warna</label>
                        <input type="color" name="warna" class="form-control form-control-color" value="#0d6efd">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="2"></textarea>
                    </div>
                    <button class="btn btn-primary w-100">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Daftar Layanan</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Layanan</th>
                            <th>Klaster</th>
                            <th>Kode</th>
                            <th>Status</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $polis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <span class="d-inline-block me-2" style="width:14px;height:14px;border-radius:4px;background:<?php echo e($poli->warna); ?>"></span>
                                <strong><?php echo e($poli->nama); ?></strong>
                                <div class="text-muted small"><?php echo e($poli->deskripsi); ?></div>
                            </td>
                            <td><?php echo e($poli->klaster?->nama); ?></td>
                            <td><span class="badge bg-secondary fs-6"><?php echo e($poli->prefix); ?></span></td>
                            <td>
                                <?php if($poli->is_active): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Nonaktif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($poli->id); ?>">Edit</button>
                                <form action="<?php echo e(route('admin.polis.destroy', $poli)); ?>" method="POST" class="d-inline"
                                      onsubmit="return confirm('Hapus layanan ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>

                        <div class="modal fade" id="edit<?php echo e($poli->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo e(route('admin.polis.update', $poli)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit <?php echo e($poli->nama); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Klaster</label>
                                                <select name="klaster_id" class="form-select" required>
                                                    <?php $__currentLoopData = $klasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($klaster->id); ?>" <?php echo e($poli->klaster_id == $klaster->id ? 'selected' : ''); ?>>
                                                            <?php echo e($klaster->nama); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Nama Layanan</label>
                                                <input type="text" name="nama" value="<?php echo e($poli->nama); ?>" class="form-control" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Kode Huruf</label>
                                                <input type="text" name="prefix" value="<?php echo e($poli->prefix); ?>" class="form-control" maxlength="4" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Warna</label>
                                                <input type="color" name="warna" value="<?php echo e($poli->warna); ?>" class="form-control form-control-color">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Deskripsi</label>
                                                <textarea name="deskripsi" class="form-control" rows="2"><?php echo e($poli->deskripsi); ?></textarea>
                                            </div>
                                            <div class="form-check form-switch">
                                                <input type="checkbox" name="is_active" value="1" class="form-check-input" id="aktif<?php echo e($poli->id); ?>" <?php echo e($poli->is_active ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="aktif<?php echo e($poli->id); ?>">Aktif</label>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\antrian-tobasa-queue\resources\views/admin/polis.blade.php ENDPATH**/ ?>